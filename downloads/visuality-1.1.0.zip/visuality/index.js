const fs = require("node:fs");
const fsp = require("node:fs/promises");
const http = require("node:http");
const path = require("node:path");

const MIME = {
  ".html": "text/html; charset=utf-8", ".htm": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8", ".js": "text/javascript; charset=utf-8",
  ".mjs": "text/javascript; charset=utf-8", ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml", ".png": "image/png", ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg", ".gif": "image/gif", ".webp": "image/webp",
  ".ico": "image/x-icon", ".woff": "font/woff", ".woff2": "font/woff2", ".ttf": "font/ttf",
};

let stopPlugin = async () => {};

module.exports = {
  activate(api) {
    let server = null;
    let serverUrl = null;
    let panelOpen = false;
    let updateTimer = null;
    let revision = 0;
    let settings = { width: 1000, height: 640, autoRefresh: true };
    let entryFile = null;

    const isInside = (root, target) => {
      const relative = path.relative(root, target);
      return relative === "" || (!relative.startsWith("..") && !path.isAbsolute(relative));
    };
    const clamp = (value, min, max, fallback) => {
      const number = Number(value);
      return Number.isFinite(number) ? Math.max(min, Math.min(max, Math.round(number))) : fallback;
    };
    const mode = () => {
      const file = api.editor.getPath() || "";
      const ext = path.extname(file).toLowerCase();
      if (ext === ".html" || ext === ".htm") {
        entryFile = file;
        return "web";
      }
      if (ext === ".x#" || ext === ".xs") return "game";
      if ([".css", ".js", ".mjs"].includes(ext) && entryFile &&
          isInside(path.dirname(entryFile), path.resolve(file))) return "web";
      return "none";
    };

    async function chooseEntry(file) {
      if (!file) return;
      const ext = path.extname(file).toLowerCase();
      if (ext === ".html" || ext === ".htm") {
        entryFile = file;
        return;
      }
      if (![".css", ".js", ".mjs"].includes(ext)) return;
      if (entryFile && isInside(path.dirname(entryFile), path.resolve(file))) return;
      entryFile = null;
      try {
        const root = path.dirname(file);
        const entries = await fsp.readdir(root, { withFileTypes: true });
        const names = entries.filter((entry) => entry.isFile() && [".html", ".htm"].includes(path.extname(entry.name).toLowerCase())).map((entry) => entry.name);
        const selected = names.find((name) => name.toLowerCase() === "index.html") ||
          names.find((name) => name.toLowerCase() === "index.htm") || names[0];
        if (selected) entryFile = path.join(root, selected);
      } catch {
        // Keep the panel empty until a matching HTML entry is opened.
      }
    }

    async function loadSettings() {
      try {
        const saved = JSON.parse(await fsp.readFile(path.join(api.plugin.dir, "settings.json"), "utf8"));
        settings = {
          width: clamp(saved.width, 320, 2200, 1000),
          height: clamp(saved.height, 240, 1600, 640),
          autoRefresh: saved.autoRefresh !== false,
        };
      } catch {
        // First launch uses defaults.
      }
    }

    async function ensureServer() {
      if (serverUrl) return serverUrl;
      server = http.createServer(async (request, response) => {
        try {
          const file = entryFile;
          if (!file) throw Object.assign(new Error("Open an HTML file to preview it."), { statusCode: 400 });
          const root = await fsp.realpath(path.dirname(file));
          let requestPath;
          try {
            requestPath = decodeURIComponent(new URL(request.url, "http://127.0.0.1").pathname);
          } catch {
            throw Object.assign(new Error("Invalid preview path."), { statusCode: 400 });
          }
          if (requestPath.includes("\0")) throw Object.assign(new Error("Invalid preview path."), { statusCode: 400 });
          const relative = requestPath.replace(/^\/+/, "") || path.basename(file);
          const target = path.resolve(root, relative);
          if (!isInside(root, target)) throw Object.assign(new Error("Path is outside the project."), { statusCode: 403 });
          const realTarget = await fsp.realpath(target);
          if (!isInside(root, realTarget)) throw Object.assign(new Error("Path is outside the project."), { statusCode: 403 });
          if (!(await fsp.stat(realTarget)).isFile()) throw Object.assign(new Error("Not a file."), { statusCode: 404 });
          const livePath = api.editor.getPath();
          let realLivePath = "";
          try { if (livePath) realLivePath = await fsp.realpath(livePath); } catch { /* source was moved */ }
          const content = realLivePath && realLivePath.toLowerCase() === realTarget.toLowerCase()
            ? api.editor.getText()
            : await fsp.readFile(realTarget);
          response.writeHead(200, {
            "Content-Type": MIME[path.extname(realTarget).toLowerCase()] || "application/octet-stream",
            "Cache-Control": "no-store",
            "X-Content-Type-Options": "nosniff",
          });
          response.end(content);
        } catch (error) {
          response.writeHead(error.statusCode || 404, { "Content-Type": "text/plain; charset=utf-8" });
          response.end(error.statusCode === 404 ? "File not found" : error.message);
        }
      });
      await new Promise((resolve, reject) => {
        server.once("error", reject);
        server.listen(0, "127.0.0.1", () => { server.off("error", reject); resolve(); });
      });
      serverUrl = "http://127.0.0.1:" + server.address().port;
      return serverUrl;
    }

    async function makeState() {
      const file = api.editor.getPath();
      const currentMode = mode();
      let previewUrl = null;
      if (currentMode === "web" && file) {
        const base = await ensureServer();
        const relative = path.relative(path.dirname(file), file).split(path.sep).map(encodeURIComponent).join("/");
        previewUrl = base + "/" + relative + "?v=" + revision;
      }
      return {
        mode: currentMode,
        file,
        text: currentMode === "web" ? "Live preview of the current HTML buffer." :
          currentMode === "game" ? "Run the X# game inside this xCode panel." :
            "Open an HTML file or X# game to preview it here.",
        previewUrl,
        settings: { ...settings },
      };
    }

    async function publish() {
      if (!panelOpen) return;
      try {
        api.ui.panelState("visuality", await makeState());
      } catch (error) {
        api.output.append("Visuality: " + error.message, "error");
      }
    }

    function schedulePublish() {
      if (!panelOpen) return;
      if (updateTimer) clearTimeout(updateTimer);
      updateTimer = setTimeout(() => {
        updateTimer = null;
        revision += 1;
        publish();
      }, settings.autoRefresh ? 250 : 0);
    }

    async function openPanel() {
      panelOpen = true;
      api.ui.openPanel("visuality");
      await publish();
    }

    api.commands.register("visuality.open", openPanel);
    api.events.onDidChange(schedulePublish);
    api.events.onDidOpen(async ({ path: file }) => { await chooseEntry(file || api.editor.getPath()); schedulePublish(); });
    api.events.onDidSave(async ({ path: file }) => { await chooseEntry(file || api.editor.getPath()); schedulePublish(); });
    api.ui.onPanelAction("visuality", async ({ action, data }) => {
      if (action === "settings") {
        settings = {
          width: clamp(data.width, 320, 2200, settings.width),
          height: clamp(data.height, 240, 1600, settings.height),
          autoRefresh: data.autoRefresh !== false,
        };
        await fsp.writeFile(path.join(api.plugin.dir, "settings.json"), JSON.stringify(settings, null, 2), "utf8");
        await publish();
        return settings;
      }
      if (action === "run-game") {
        return api.runtime.runCurrent({ width: settings.width, height: settings.height, inline: true });
      }
      if (action === "stop-game") return api.runtime.stop();
      if (action === "close") { panelOpen = false; return true; }
      return null;
    });

    loadSettings().then(publish);
    stopPlugin = async () => {
      if (panelOpen) api.ui.closePanel("visuality");
      if (updateTimer) clearTimeout(updateTimer);
      if (server) await new Promise((resolve) => server.close(resolve));
      server = null;
      serverUrl = null;
      panelOpen = false;
    };
  },
  deactivate() { return stopPlugin(); },
};
